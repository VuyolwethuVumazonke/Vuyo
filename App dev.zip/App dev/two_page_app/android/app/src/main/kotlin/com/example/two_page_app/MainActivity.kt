package com.example.two_page_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
