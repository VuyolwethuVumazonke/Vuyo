import 'package:flutter/material.dart';
import 'package:appdev/Display.dart';
import 'package:appdev/to_does.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My app',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Flutter To Do List'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<ToDoz> todozz =[
    ToDoz(title: 'Wash a car', description: 'I washed a car with muddy water', color: Colors.red),
    ToDoz(title: 'Went to store', description: 'I went to buy something to eat', color: Colors.blue),
    ToDoz(title: 'Folded clothes', description: 'I folded my clothes after', color: Colors.orange)

  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(


        floatingActionButton: FloatingActionButton(
          onPressed: (){
            Navigator.push((context),
                MaterialPageRoute(builder:(context)=> const Display(),
                )
            );
          },
          child: const Icon(Icons.add),
        ),
        appBar: AppBar(

          title: Text(widget.title),
        ),
        body: ListView.builder(

            itemCount: todozz.length,
            itemBuilder: (context,index){
              return Padding(padding: EdgeInsets.only(bottom: 2.0),
                child: Card(
                  color: todozz[index].color,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical:18.0 ,horizontal:10.0 ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(todozz[index].title),
                            Text(todozz[index].description)
                          ],
                        ),
                        const Icon(Icons.check_box)
                      ],
                    ),
                  ),
                ) ,
              );
            })
    );
  }}