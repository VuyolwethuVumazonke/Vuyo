import 'package:flutter/material.dart';


class ToDoz {
  late String title;
  late String description;
  late Color color;

  ToDoz({ required this.title, required this.description, required this.color});

}


