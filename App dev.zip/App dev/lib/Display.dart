
import 'package:flutter/material.dart';

void main(){
  runApp(const MaterialApp());
}
class Display extends StatefulWidget {
  const Display({Key? key}) : super(key: key);
  @override
  State<Display> createState() => _DisplayState();
}
class _DisplayState extends State<Display> {
  String title='';
  String description='';
  String priority='red';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const Display()
              )
          );
        },
        child: const Icon(Icons.done ),

      ),
      appBar: AppBar(
        title: const Text('Second page') ,
        centerTitle: true,

      ),
      body: Container(
        margin: const EdgeInsets.all(2.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
                'Title:',
                style: TextStyle(
                    fontSize: 20.0
                )
            ),


            const SizedBox(height: 10.0),
            //#1
            TextField(
              onChanged: (value){
                setState(() {
                  title= value;
                });
              },
              style: const TextStyle(
                color: Colors.black,
              ),
              decoration: InputDecoration(
                  hintText: 'Enter title',
                  hintStyle: const TextStyle(
                    color: Colors.blueGrey,
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(5.0)
                  )
              ),
            ),
            //#1
            const Text(
                'Description:',
                style: TextStyle(
                    fontSize: 20.0
                )
            ),
            const SizedBox(height: 10.0),

            TextField(
              onChanged: (value){
                setState(() {
                  title= value;

                });
              },
              style: const TextStyle(
                color: Colors.black,
              ),
              decoration: InputDecoration(
                  hintText: 'Enter description',
                  hintStyle: const TextStyle(
                    color: Colors.blueGrey,
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(5.0)
                  )
              ),
            ),

//dropdown button
            //dropdown

            DropdownButton(
              value: priority,
              isExpanded: true,
              items: const[
                DropdownMenuItem(
                    value: 'red',
                    child: Text("red")
                ),
                DropdownMenuItem(
                  value: 'orange',
                  child: Text("orange"),),
                DropdownMenuItem(
                  value: 'blue',
                  child: Text("blue"),)
              ],
              onChanged: (value){},
            ),
            const SizedBox(height: 20.0)
          ],
        ),
      ),
    );
  }
}
