package com.example.appdev

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
